package cr.ac.una.backend.enumeration;


public enum Estado {
    PENDIENTE,
    EN_PROGRESO,
    COMPLETADA
}