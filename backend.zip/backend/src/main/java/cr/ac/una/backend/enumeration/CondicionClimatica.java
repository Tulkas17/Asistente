package cr.ac.una.backend.enumeration;

public enum CondicionClimatica {
    SOLEADO,
    NUBLADO,
    LLUVIOSO,
    VENTOSO,
    INDEPENDIENTE // Significa que la tarea no depende del clima
}
