package cr.ac.una.backend.enumeration;

public enum Prioridad {
    ALTA,
    MEDIA,
    BAJA
}